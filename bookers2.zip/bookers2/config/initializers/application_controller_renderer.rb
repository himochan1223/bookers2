# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'cc2db752fae17e8bca226550c55198a888e3dd7f95bae0944d7e56d38d1d00f645725e5ad04bed8dc4c51643a6a4e46aac10f6c37b63c0b6e8155a1debde5dec'