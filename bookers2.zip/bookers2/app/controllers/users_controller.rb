class UsersController < ApplicationController
  def index
    @user = current_user  # サイドバーに表示するログインユーザー情報の表示用
    @users = User.all  # ユーザー一覧の表示用
    @book = Book.new  # 投稿フォーム用（form_with用）
  end

  def show
    @user = User.find(params[:id])  # 当該ユーザー情報表示用
    @book = Book.new  # 投稿用（form_with用）
    @books = @user.books.all  # 投稿ユーザーの投稿一覧（アソシエーションを利用）
  end

  def edit
    @user = User.find(params[:id])
    if @user != current_user
      redirect_to user_path(current_user.id)
    end
  end

  def update
    @user = User.find(params[:id])
    if @user.update(user_params)
      flash[:notice] = 'You have updated user successfully.'
      redirect_to user_path(@user)
    else
      render :edit
    end
  end

  private

  def user_params
    params.require(:user).permit(:name, :profile_image, :introduction)
  end
end
